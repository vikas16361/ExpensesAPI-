package in.bushansirgur.expensetrackerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensetrackerapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
